package com.gatheringhallstudios.mhworlddatabase.data.embeds;

/**
 * Represents a collection of weaknesses
 */
public class WeaknessSummaryElemental {
    public Integer fire;
    public Integer water;
    public Integer ice;
    public Integer thunder;
    public Integer dragon;
}
