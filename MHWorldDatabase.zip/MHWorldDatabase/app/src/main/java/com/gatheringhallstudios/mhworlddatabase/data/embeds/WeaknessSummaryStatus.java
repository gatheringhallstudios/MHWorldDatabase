package com.gatheringhallstudios.mhworlddatabase.data.embeds;

public class WeaknessSummaryStatus {
    public Integer poison;
    public Integer sleep;
    public Integer paralysis;
    public Integer blast;
    public Integer stun;
}
